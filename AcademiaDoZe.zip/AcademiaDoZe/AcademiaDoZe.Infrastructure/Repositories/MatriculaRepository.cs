﻿// Gustavo vinicius Ribeiro Kley
using AcademiaDoZe.Domain.Entities;
using AcademiaDoZe.Domain.Enums;
using AcademiaDoZe.Domain.Repositories;
using AcademiaDoZe.Domain.ValueObjects;
using AcademiaDoZe.Infrastructure.Data;
using System.Data;
using System.Data.Common;

namespace AcademiaDoZe.Infrastructure.Repositories
{
    public class MatriculaRepository : BaseRepository<Matricula>, IMatriculaRepository
    {
        public MatriculaRepository(string connectionString, DatabaseType databaseType)
            : base(connectionString, databaseType) { }

        protected override async Task<Matricula> MapAsync(DbDataReader reader)
        {
            try
            {
                // Obtém o logradouro
                var logradouroId = Convert.ToInt32(reader["logradouro_id"]);
                var logradouroRepository = new LogradouroRepository(_connectionString, _databaseType);
                var logradouro = await logradouroRepository.ObterPorId(logradouroId)
                    ?? throw new InvalidOperationException($"Logradouro com ID {logradouroId} não encontrado.");

                // procurar o aluno 
                var alunoId = Convert.ToInt32(reader["aluno_id"]);
                var repoAluno = new AlunoRepository(_connectionString, _databaseType);
                var aluno = await repoAluno.ObterPorId(alunoId)
                            ?? throw new InvalidOperationException($"Aluno com ID {alunoId} não encontrado.");
                // Cria o objeto Matricula usando o método de fábrica
                var matricula = Matricula.Criar(
                    alunoMatricula: aluno,
                    plano: (ETipoPlano)Convert.ToInt32(reader["plano"]),
                    dataInicio: DateOnly.FromDateTime(Convert.ToDateTime(reader["data_inicio"])),
                    dataFim: DateOnly.FromDateTime(Convert.ToDateTime(reader["data_fim"])),
                    objetivo: reader["objetivo"].ToString()!,
                    restricoesMedicas: (EMatriculaRestricoes)Convert.ToInt32(reader["restricoes_medicas"]),
                    laudoMedico: reader["laudo_medico"] is DBNull ? null : Arquivo.Criar((byte[])reader["laudo_medico"], "jpg"),
                    observacoesRestricoes: reader["observacoes_restricoes"]?.ToString()
                );

                // Define o ID usando reflection
                var idProperty = typeof(Entity).GetProperty("Id");
                idProperty?.SetValue(matricula, Convert.ToInt32(reader["id_matricula"]));

                return matricula;
            }
            catch (DbException ex)
            {
                throw new InvalidOperationException($"Erro ao mapear dados da matrícula: {ex.Message}", ex);
            }
        }

        public override async Task<Matricula> Adicionar(Matricula entity)
        {
            try
            {
                await using var connection = await GetOpenConnectionAsync();

                string query = _databaseType == DatabaseType.SqlServer
                    ? $"INSERT INTO {TableName} (aluno_id, plano, data_inicio, data_fim, objetivo, restricoes_medicas, observacoes_restricoes, laudo_medico) " +
                      "OUTPUT INSERTED.id_matricula " +
                      "VALUES (@AlunoId, @Plano, @DataInicio, @DataFim, @Objetivo, @RestricoesMedicas, @ObservacoesRestricoes, @LaudoMedico);"
                    : $"INSERT INTO {TableName} (aluno_id, plano, data_inicio, data_fim, objetivo, restricoes_medicas, observacoes_restricoes, laudo_medico) " +
                      "VALUES (@AlunoId, @Plano, @DataInicio, @DataFim, @Objetivo, @RestricoesMedicas, @ObservacoesRestricoes, @LaudoMedico); " +
                      "SELECT LAST_INSERT_ID();";

                await using var command = DbProvider.CreateCommand(query, connection);
                command.Parameters.Add(DbProvider.CreateParameter("@AlunoId", entity.AlunoMatricula.Id, DbType.Int32, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@Plano", (int)entity.Plano, DbType.Int32, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@DataInicio", entity.DataInicio, DbType.Date, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@DataFim", entity.DataFim, DbType.Date, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@Objetivo", entity.Objetivo, DbType.String, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@RestricoesMedicas", (int)entity.RestricoesMedicas, DbType.Int32, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@ObservacoesRestricoes", (object?)entity.ObservacoesRestricoes ?? DBNull.Value, DbType.String, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@LaudoMedico", (object?)entity.LaudoMedico?.Conteudo ?? DBNull.Value, DbType.Binary, _databaseType));

                var id = await command.ExecuteScalarAsync();

                if (id != null && id != DBNull.Value)
                {
                    var idProperty = typeof(Entity).GetProperty("Id");
                    idProperty?.SetValue(entity, Convert.ToInt32(id));
                }

                return entity;
            }
            catch (DbException ex)
            {
                throw new InvalidOperationException($"Erro ao adicionar matrícula: {ex.Message}", ex);
            }
        }

        public override async Task<Matricula> Atualizar(Matricula entity)
        {
            try
            {
                await using var connection = await GetOpenConnectionAsync();

                string query = $"UPDATE {TableName} " +
                               "SET aluno_id = @AlunoId, " +
                               "plano = @Plano, " +
                               "data_inicio = @DataInicio, " +
                               "data_fim = @DataFim, " +
                               "objetivo = @Objetivo, " +
                               "restricoes_medicas = @RestricoesMedicas, " +
                               "observacoes_restricoes = @ObservacoesRestricoes, " +
                               "laudo_medico = @LaudoMedico " +
                               "WHERE id_matricula = @Id";

                await using var command = DbProvider.CreateCommand(query, connection);
                command.Parameters.Add(DbProvider.CreateParameter("@Id", entity.Id, DbType.Int32, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@AlunoId", entity.AlunoMatricula.Id, DbType.Int32, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@Plano", (int)entity.Plano, DbType.Int32, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@DataInicio", entity.DataInicio, DbType.Date, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@DataFim", entity.DataFim, DbType.Date, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@Objetivo", entity.Objetivo, DbType.String, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@RestricoesMedicas", (int)entity.RestricoesMedicas, DbType.Int32, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@ObservacoesRestricoes", (object?)entity.ObservacoesRestricoes ?? DBNull.Value, DbType.String, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@LaudoMedico", (object?)entity.LaudoMedico?.Conteudo ?? DBNull.Value, DbType.Binary, _databaseType));

                int rowsAffected = await command.ExecuteNonQueryAsync();

                if (rowsAffected == 0)
                {
                    throw new InvalidOperationException($"Nenhuma matrícula encontrada com o ID {entity.Id} para atualização.");
                }

                return entity;
            }
            catch (DbException ex)
            {
                throw new InvalidOperationException($"Erro ao atualizar matrícula com ID {entity.Id}: {ex.Message}", ex);
            }
        }

        public async Task<IEnumerable<Matricula>> ObterPorAluno(int alunoId)
        {
            try
            {
                var lista = new List<Matricula>();

                await using var connection = await GetOpenConnectionAsync();
                string query = $"SELECT * FROM {TableName} WHERE aluno_id = @AlunoId";

                await using var command = DbProvider.CreateCommand(query, connection);
                command.Parameters.Add(DbProvider.CreateParameter("@AlunoId", alunoId, DbType.Int32, _databaseType));

                using var reader = await command.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    lista.Add(await MapAsync(reader));
                }

                return lista;
            }
            catch (DbException ex)
            {
                throw new InvalidOperationException($"Erro ao obter matrículas do aluno {alunoId}: {ex.Message}", ex);
            }
        }

        public async Task<IEnumerable<Matricula>> ObterAtivas()
        {
            try
            {
                var lista = new List<Matricula>();

                await using var connection = await GetOpenConnectionAsync();
                string query = $"SELECT * FROM {TableName} WHERE data_fim >= CURRENT_DATE";

                await using var command = DbProvider.CreateCommand(query, connection);

                using var reader = await command.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    lista.Add(await MapAsync(reader));
                }

                return lista;
            }
            catch (DbException ex)
            {
                throw new InvalidOperationException($"Erro ao obter matrículas ativas: {ex.Message}", ex);
            }
        }

        public async Task<IEnumerable<Matricula>> ObterVencendoEmDias(int dias)
        {
            try
            {
                var lista = new List<Matricula>();

                await using var connection = await GetOpenConnectionAsync();
                string query = $"SELECT * FROM {TableName} " +
                               "WHERE data_fim BETWEEN CURRENT_DATE AND DATEADD(DAY, @Dias, CURRENT_DATE)";

                await using var command = DbProvider.CreateCommand(query, connection);
                command.Parameters.Add(DbProvider.CreateParameter("@Dias", dias, DbType.Int32, _databaseType));

                using var reader = await command.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    lista.Add(await MapAsync(reader));
                }

                return lista;
            }
            catch (DbException ex)
            {
                throw new InvalidOperationException($"Erro ao obter matrículas vencendo em {dias} dias: {ex.Message}", ex);
            }
        }
    }
}
