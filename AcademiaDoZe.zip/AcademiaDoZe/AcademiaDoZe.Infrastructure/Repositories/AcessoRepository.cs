﻿// Gustavo Vinicius Ribeiro Kley
using AcademiaDoZe.Domain.Entities;
using AcademiaDoZe.Domain.Enums;
using AcademiaDoZe.Domain.Repositories;
using AcademiaDoZe.Infrastructure.Data;
using System.Data;
using System.Data.Common;
namespace AcademiaDoZe.Infrastructure.Repositories
{
    public class AcessoRepository : BaseRepository<Acesso>, IAcessoRepository
    {
        public AcessoRepository(string connectionString, DatabaseType databaseType)
            : base(connectionString, databaseType) { }
        protected override async Task<Acesso> MapAsync(DbDataReader reader)
        {
            try
            {
                var tipo = (EPessoaTipo)Convert.ToInt32(reader["tipo"]);
                var pessoaId = Convert.ToInt32(reader["pessoa_id"]);
                var dataHora = Convert.ToDateTime(reader["data_hora"]);

                // Buscar pessoa (Aluno ou Colaborador)
                Pessoa pessoa;
                if (tipo == EPessoaTipo.Aluno)
                {
                    var repoAluno = new AlunoRepository(_connectionString, _databaseType);
                    pessoa = await repoAluno.ObterPorId(pessoaId) ?? throw new InvalidOperationException($"Aluno {pessoaId} não encontrado.");
                }
                else
                {
                    var repoColaborador = new ColaboradorRepository(_connectionString, _databaseType);
                    pessoa = await repoColaborador.ObterPorId(pessoaId) ?? throw new InvalidOperationException($"Colaborador {pessoaId} não encontrado.");
                }

                var acesso = Acesso.Criar(tipo, pessoa, dataHora);

                // Define Id
                var idProperty = typeof(Entity).GetProperty("Id");
                idProperty?.SetValue(acesso, Convert.ToInt32(reader["id_acesso"]));

                return acesso;
            }
            catch (DbException ex)
            {
                throw new InvalidOperationException($"Erro ao mapear acesso: {ex.Message}", ex);
            }
        }
        public override async Task<Acesso> Adicionar(Acesso entity)
        {
            try
            {
                await using var connection = await GetOpenConnectionAsync();

                string query = _databaseType == DatabaseType.SqlServer
                    ? $"INSERT INTO {TableName} (tipo, pessoa_id, data_hora) OUTPUT INSERTED.id_acesso VALUES (@Tipo, @PessoaId, @DataHora);"
                    : $"INSERT INTO {TableName} (tipo, pessoa_id, data_hora) VALUES (@Tipo, @PessoaId, @DataHora); SELECT LAST_INSERT_ID();";

                await using var command = DbProvider.CreateCommand(query, connection);
                command.Parameters.Add(DbProvider.CreateParameter("@Tipo", (int)entity.Tipo, DbType.Int32, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@PessoaId", entity.AlunoColaborador.Id, DbType.Int32, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@DataHora", entity.DataHora, DbType.DateTime, _databaseType));

                var id = await command.ExecuteScalarAsync();
                if (id != null && id != DBNull.Value)
                {
                    var idProperty = typeof(Entity).GetProperty("Id");
                    idProperty?.SetValue(entity, Convert.ToInt32(id));
                }

                return entity;
            }
            catch (DbException ex)
            {
                throw new InvalidOperationException($"Erro ao adicionar acesso: {ex.Message}", ex);
            }
        }
        public override async Task<Acesso> Atualizar(Acesso entity)
        {
            try
            {
                await using var connection = await GetOpenConnectionAsync();

                string query = $"UPDATE {TableName} SET tipo=@Tipo, pessoa_id=@PessoaId, data_hora=@DataHora WHERE id_acesso=@Id";
                await using var command = DbProvider.CreateCommand(query, connection);
                command.Parameters.Add(DbProvider.CreateParameter("@Id", entity.Id, DbType.Int32, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@Tipo", (int)entity.Tipo, DbType.Int32, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@PessoaId", entity.AlunoColaborador.Id, DbType.Int32, _databaseType));
                command.Parameters.Add(DbProvider.CreateParameter("@DataHora", entity.DataHora, DbType.DateTime, _databaseType));
                int rowsAffected = await command.ExecuteNonQueryAsync();
                if (rowsAffected == 0)
                    throw new InvalidOperationException($"Nenhum acesso encontrado com ID {entity.Id}.");
                return entity;
            }
            catch (DbException ex)
            {
                throw new InvalidOperationException($"Erro ao atualizar acesso {entity.Id}: {ex.Message}", ex);
            }
        }

        public async Task<IEnumerable<Acesso>> GetAcessosPorAlunoPeriodo(int? alunoId = null, DateOnly? inicio = null, DateOnly? fim = null)
        {
            var lista = new List<Acesso>();
            await using var connection = await GetOpenConnectionAsync();
            string query = $"SELECT * FROM {TableName} WHERE (@AlunoId IS NULL OR pessoa_id=@AlunoId) " +
                           "AND (@Inicio IS NULL OR data_hora >= @Inicio) AND (@Fim IS NULL OR data_hora <= @Fim)";
            await using var command = DbProvider.CreateCommand(query, connection);
            command.Parameters.Add(DbProvider.CreateParameter("@AlunoId", alunoId ?? (object?)DBNull.Value, DbType.Int32, _databaseType));
            command.Parameters.Add(DbProvider.CreateParameter("@Inicio", inicio?.ToDateTime(TimeOnly.MinValue) ?? (object?)DBNull.Value, DbType.DateTime, _databaseType));
            command.Parameters.Add(DbProvider.CreateParameter("@Fim", fim?.ToDateTime(TimeOnly.MaxValue) ?? (object?)DBNull.Value, DbType.DateTime, _databaseType));

            using var reader = await command.ExecuteReaderAsync();
            while (await reader.ReadAsync())
                lista.Add(await MapAsync(reader));

            return lista;
        }

        public async Task<IEnumerable<Acesso>> GetAcessosPorColaboradorPeriodo(int? colaboradorId = null, DateOnly? inicio = null, DateOnly? fim = null)
        {
            var lista = new List<Acesso>();
            await using var connection = await GetOpenConnectionAsync();
            string query = $"SELECT * FROM {TableName} WHERE (@ColaboradorId IS NULL OR pessoa_id=@ColaboradorId) " +
                           "AND (@Inicio IS NULL OR data_hora >= @Inicio) AND (@Fim IS NULL OR data_hora <= @Fim)";
            await using var command = DbProvider.CreateCommand(query, connection);
            command.Parameters.Add(DbProvider.CreateParameter("@ColaboradorId", colaboradorId ?? (object?)DBNull.Value, DbType.Int32, _databaseType));
            command.Parameters.Add(DbProvider.CreateParameter("@Inicio", inicio?.ToDateTime(TimeOnly.MinValue) ?? (object?)DBNull.Value, DbType.DateTime, _databaseType));
            command.Parameters.Add(DbProvider.CreateParameter("@Fim", fim?.ToDateTime(TimeOnly.MaxValue) ?? (object?)DBNull.Value, DbType.DateTime, _databaseType));

            using var reader = await command.ExecuteReaderAsync();
            while (await reader.ReadAsync())
                lista.Add(await MapAsync(reader));

            return lista;
        }

        public Task<Dictionary<TimeOnly, int>> GetHorarioMaisProcuradoPorMes(int mes)
        {
            throw new NotImplementedException();
        }

        public Task<Dictionary<int, TimeSpan>> GetPermanenciaMediaPorMes(int mes)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<Aluno>> GetAlunosSemAcessoNosUltimosDias(int dias)
        {
            throw new NotImplementedException();
        }
    }
}
