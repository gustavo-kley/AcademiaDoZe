﻿namespace AcademiaDoZe.Infrastructure
{
    public class Class1
    {

    }
}
