﻿// Gustavo vinicius Ribeiro Kley

using AcademiaDoZe.Domain.Enums;
using AcademiaDoZe.Domain.Exceptions;
using AcademiaDoZe.Domain.Services;
using AcademiaDoZe.Domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace AcademiaDoZe.Domain.Entities
{
    public class Matricula : Entity
    {
        // encapsulamento das propriedades, aplicando imutabilidade
        public Aluno AlunoMatricula { get; private set; }
        public ETipoPlano Plano { get; private set; }
        public DateOnly DataInicio { get; private set; }
        public DateOnly DataFim { get; private set; }
        public string Objetivo { get; private set; }
        public EMatriculaRestricoes RestricoesMedicas { get; private set; }
        public string ObservacoesRestricoes { get; private set; }
        public Arquivo LaudoMedico { get; private set; }
        // construtor privado para evitar instância direta
        private Matricula(Aluno alunoMatricula, ETipoPlano plano, DateOnly dataInicio, DateOnly dataFim, string objetivo, EMatriculaRestricoes restricoesMedicas, Arquivo laudoMedico, string observacoesRestricoes = "")
        : base()
        {
            AlunoMatricula = alunoMatricula;
            Plano = plano;
            DataInicio = dataInicio;
            DataFim = dataFim;
            Objetivo = objetivo;
            RestricoesMedicas = restricoesMedicas;
            LaudoMedico = laudoMedico;
            ObservacoesRestricoes = observacoesRestricoes;
        }
        // método de fábrica, ponto de entrada para criar um objeto válido
        public static Matricula Criar(Aluno alunoMatricula, ETipoPlano plano, DateOnly dataInicio, DateOnly dataFim, string objetivo, EMatriculaRestricoes restricoesMedicas, Arquivo laudoMedico, string
        observacoesRestricoes = "")
        {
            // Validações e normalizações
            if (alunoMatricula == null) throw new DomainException("ALUNO_INVALIDO");
            if (alunoMatricula.DataNascimento > DateOnly.FromDateTime(DateTime.Today.AddYears(-16)) && laudoMedico == null) throw new DomainException("MENOR16_LAUDO_OBRIGATORIO");
            if (!Enum.IsDefined(plano)) throw new DomainException("PLANO_INVALIDO");
            if (dataInicio == default) throw new DomainException("DATA_INICIO_OBRIGATORIO");
            // dataFim
            if (NormalizadoService.TextoVazioOuNulo(objetivo)) throw new DomainException("OBJETIVO_OBRIGATORIO");
            objetivo = NormalizadoService.LimparEspacos(objetivo);
            if (restricoesMedicas != EMatriculaRestricoes.None && laudoMedico == null) throw new DomainException("RESTRICOES_LAUDO_OBRIGATORIO");
            observacoesRestricoes = NormalizadoService.LimparEspacos(observacoesRestricoes);
            // Não permitir nova matrícula se ainda tiver matrícula ativa.
            // dependeremos da persistência para verificar se o aluno já possui matrícula ativa.

            // criação e retorno do objeto
            return new Matricula(alunoMatricula, plano, dataInicio, dataFim, objetivo, restricoesMedicas, laudoMedico, observacoesRestricoes);
        }

        public static Colaborador Criar(string alunoMatricula, string plano, DateOnly dataInicio, DateOnly dataFim, string objetivo, EMatriculaRestricoes restricoesMedicas, Arquivo? laudoMedico)
        {
            throw new NotImplementedException();
        }

        public static Matricula Criar(int id, Aluno aluno, ETipoPlano eTipoPlano, DateOnly dataInicio, DateOnly dataFim, string objetivo, EMatriculaRestricoes eMatriculaRestricoes, Arquivo arquivo, string v)
        {
            throw new NotImplementedException();
        }
    }
}