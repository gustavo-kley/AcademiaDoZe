﻿//// Gustavo vinicius Ribeiro Kley
//using AcademiaDoZe.Domain.Entities;
//using AcademiaDoZe.Domain.Services;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AcademiaDoZe.Domain.Repositories
//{

//    public class AlunoRepository : IAlunoRepository
//    {
//        private readonly List<Aluno> alunos = new();

//        public bool ExisteCpf(string cpf)
//        {
//            cpf = NormalizadoService.LimparEDigitos(cpf);
//            return alunos.Any(a => a.CPF == cpf);
//        }

//        public void Adicionar(Aluno aluno)
//        {
//            alunos.Add(aluno);
//        }

//        public Aluno? ObterPorId(Guid id)
//        {
//            return alunos.FirstOrDefault(a => a.Id == id);
//        }

//        public IEnumerable<Aluno> ListarTodos()
//        {
//            return alunos;
//        }
//    }
//}

