﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//gustavo vinicius ribeiro kley
using AcademiaDoZe.Domain.Entities;
namespace AcademiaDoZe.Domain.Repositories
{
    public interface ILogradouroRepository : IRepository<Logradouro>
    {
        // Métodos específicos do domínio

        Task<Logradouro?> ObterPorCep(string cep);

        Task<IEnumerable<Logradouro>> ObterPorCidade(string cidade);
    }
}
