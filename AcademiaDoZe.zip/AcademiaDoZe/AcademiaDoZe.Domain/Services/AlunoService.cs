﻿//// Gustavo vinicius Ribeiro Kley
//using AcademiaDoZe.Domain.Entities;
//using AcademiaDoZe.Domain.Exceptions;
//using AcademiaDoZe.Domain.Repositories;
//using AcademiaDoZe.Domain.ValueObjects;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AcademiaDoZe.Domain.Services
//{
//    public class AlunoService
//    {
//        private readonly IAlunoRepository _alunoRepository;

//        public AlunoService(IAlunoRepository alunoRepository)
//        {
//            _alunoRepository = alunoRepository;
//        }

//        // metodo para criar aluno e validar se já tem um cpf cadastrado
//        public Aluno CriarAluno(string nomeCompleto, string cpf, DateOnly dataNascimento,
//            string telefone, string email, string senha, Logradouro logradouro,
//            string numero, string complemento, Arquivo foto)
//        {
//            cpf = NormalizadoService.LimparEDigitos(cpf);

//            if (_alunoRepository.ExisteCpf(cpf))
//                throw new DomainException("CPF_JA_CADASTRADO");

//            var aluno = Aluno.Criar(nomeCompleto, cpf, dataNascimento,
//                telefone, email, senha, logradouro, numero, complemento, foto);

//            _alunoRepository.Adicionar(aluno);
//            //retorna o aluno
//            return aluno;
//        }
//    }

//}
