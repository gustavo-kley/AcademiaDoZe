﻿//// Gustavo Vinicus Ribeiro Kley
//using AcademiaDoZe.Domain.Entities;
//using AcademiaDoZe.Domain.Repositories;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AcademiaDoZe.Domain.Services
//{

//    public class AcessoService
//    {
//        // guarda a referencia no repositorio de acesso
//        private readonly AcessoRepository _acessoRepository;

//        // construtor do controle de acesso
//        public AcessoService(AcessoRepository acessoRepository)
//        {
//            _acessoRepository = acessoRepository;
//        }

//        // metodo de registrar o acesso 
//        public Acesso RegistrarAcesso(Pessoa pessoa)
//        {
//            var agora = DateTime.Now;

//            var acesso = Acesso.Criar(pessoa, agora);
//            _acessoRepository.Registrar(acesso);

//            return acesso;
//        }
//        // metodo que retorna o ultimo acesso da pessoa com o ID
//        public IEnumerable<Acesso> ObterUltimoAcesso(Guid pessoaId, int quantidade = 1)
//        {
//            return _acessoRepository.ListarUltimoAcesso(pessoaId, quantidade);
//        }
//    }
//}
