﻿//// Gustavo vinicius Ribeiro Kley
//using AcademiaDoZe.Domain.Entities;
//using AcademiaDoZe.Domain.Enums;
//using AcademiaDoZe.Domain.Exceptions;
//using AcademiaDoZe.Domain.Repositories;
//using AcademiaDoZe.Domain.ValueObjects;
//using System;
//using System.Collections.Generic;
//using System.Text;
//using System.Threading.Tasks;

//namespace AcademiaDoZe.Domain.Services
//{
//    public class ColaboradorService
//    {
//        private readonly IColaboradorRepository _colaboradorRepository;

//        public ColaboradorService(IColaboradorRepository colaboradorRepository)
//        {
//            _colaboradorRepository = colaboradorRepository;
//        }

//        // metodo para criar aluno e validar se já tem um cpf cadastrado
//        public Colaborador CriarColaborador(string nomeCompleto, string cpf, DateOnly dataNascimento, string telefone, string email, string senha,
//            Logradouro logradouro, string numero, string complemento, Arquivo foto, DateOnly dataAdmissao,
//            EColaboradorTipo tipo, EColaboradorVinculo vinculo)
//        {
//            cpf = NormalizadoService.LimparEDigitos(cpf);

//            if (_colaboradorRepository.ExisteCpf(cpf))
//                throw new DomainException("CPF_JA_CADASTRADO");

//            var colaborador = Colaborador.Criar(nomeCompleto, cpf, dataNascimento,
//                telefone, email, senha, logradouro, numero, complemento, foto, dataAdmissao, tipo, vinculo);

//            _colaboradorRepository.Adicionar(colaborador);
//            //retorna o aluno
//            return colaborador;
//        }
//    }
//}
