﻿//// Gustavo vinicius Ribeiro Kley
//using AcademiaDoZe.Domain.Entities;
//using AcademiaDoZe.Domain.Enums;
//using AcademiaDoZe.Domain.Exceptions;
//using AcademiaDoZe.Domain.Repositories;
//using AcademiaDoZe.Domain.ValueObjects;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AcademiaDoZe.Domain.Services
//{
//    public class MatriculaService
//    {
//        private readonly MatriculaRepository _matriculaRepository;

//        public MatriculaService(MatriculaRepository matriculaRepository)
//        {
//            _matriculaRepository = matriculaRepository;
//        }

//        public Matricula RealizarMatricula(
//            Aluno aluno,
//            ETipoPlano plano,
//            DateOnly dataInicio,
//            DateOnly dataFinal,
//            string objetivo,
//            EMatriculaRestricoes restricoes,
//            string observacoes,
//            Arquivo? laudoMedico)
//        {
//            if (_matriculaRepository.ExisteMatriculaAtivaPorAluno(aluno.Id))
//                throw new DomainException("ALUNO_JA_POSSUI_MATRICULA_ATIVA");

//            var matricula = Matricula.Criar(
//                aluno, plano, dataInicio, dataFinal,
//                objetivo, restricoes, observacoes, laudoMedico);

//            _matriculaRepository.Adicionar(matricula);
//            return matricula;
//        }
//    }
//}
