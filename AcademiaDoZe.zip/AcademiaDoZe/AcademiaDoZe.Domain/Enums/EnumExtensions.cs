﻿// Gustavo vinicius Ribeiro Kley
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademiaDoZe.Domain.Enums
{
    public static class EnumExtensions
    {
        public static string GetDisplayName(this Enum value)
        {
            // Pega o campo do enum correspondente ao valor atual.
            var field = value.GetType().GetField(value.ToString());

            // Procura se esse campo tem um [Display(Name = "...")].
            var attribute = field?.GetCustomAttribute<DisplayAttribute>();

            // Se achou o atributo Display, retorna o nome amigável (attribute.Name).
            // Caso contrário, retorna o nome real do enum (value.ToString()).
            return attribute?.Name ?? value.ToString();
        }
    }
}
