﻿// Gustavo vinicius Ribeiro Kley
using System;
using System.ComponentModel.DataAnnotations;

namespace AcademiaDoZe.Domain.Enums
{
    public enum EColaboradorVinculo
    {
        [Display(Name = "CLT")]
        CLT = 1,
        [Display(Name = "Estagiário")]
        Estagio = 2
    }
}
