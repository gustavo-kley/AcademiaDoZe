[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "AcademiaDoZe.Presentation.AppMaui")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "AcademiaDoZe.Presentation.AppMaui.Pages")]
