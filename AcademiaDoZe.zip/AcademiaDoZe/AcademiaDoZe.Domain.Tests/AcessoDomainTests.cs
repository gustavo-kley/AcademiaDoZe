﻿using AcademiaDoZe.Domain.Entities;
using AcademiaDoZe.Domain.Enums;
using AcademiaDoZe.Domain.Exceptions;
using AcademiaDoZe.Domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace AcademiaDoZe.Domain.Tests
{
    public class AcessoDomainTests
    {
        // Cria um Aluno válido para os testes
        private Aluno AlunoValido()
        {
            var logradouro = Logradouro.Criar("12345678", "Rua A", "Centro", "Cidade", "SP", "Brasil");

            var foto = Arquivo.Criar(new byte[1], ".jpg");


            return Aluno.Criar("Gustavo Kley", "12345678901",DateOnly.FromDateTime(DateTime.Today.AddYears(-20)),"11999999999", "gustavo@email.com",logradouro,"123", "Apto 1", "Senha@1", foto);
        }
        private Colaborador ColaboradorValido()
        {
            var logradouro = Logradouro.Criar("12345678", "Rua A", "Centro", "Cidade", "SP", "Brasil");
            var foto = Arquivo.Criar(new byte[1], ".jpg");
            var tipo = EColaboradorTipo.Instrutor;
            var vinculo = EColaboradorVinculo.CLT;

            var dataAdmissao = new DateOnly(2025, 02, 02);
            return Colaborador.Criar("Gustavo Kley", "12345678901", DateOnly.FromDateTime(DateTime.Today.AddYears(-20)), "11999999999", "gustavo@email.com", logradouro, "123", "Apto 1", "Senha@1",
                foto, dataAdmissao, tipo, vinculo);
        }

        [Fact]
        public void CriarAcessoAluno_ComDadosValidos_DeveCriarObjeto()
        {
            // Arrange
            var aluno = AlunoValido();
            var tipo = EPessoaTipo.Aluno;

            // Garante que é uma hora válida (entre 6h e 22h) e no futuro
            var dataHora = DateTime.Now.AddMinutes(1);
            if (dataHora.TimeOfDay < new TimeSpan(6, 0, 0))
                dataHora = DateTime.Today.AddHours(6);
            else if (dataHora.TimeOfDay > new TimeSpan(22, 0, 0))
                dataHora = DateTime.Today.AddDays(1).AddHours(6);

            // Act
            var acesso = Acesso.Criar(tipo, aluno, dataHora);

            // Assert
            Assert.NotNull(acesso);
        }

        [Fact]
        public void CriarAcessoColaborador_ComDadosValidos_DeveCriarObjeto()
        {
            // Arrange
            var colaborador = ColaboradorValido();
            var tipo = EPessoaTipo.Aluno;

            // Garante que é uma hora válida (entre 6h e 22h) e no futuro
            var dataHora = DateTime.Now.AddMinutes(1);
            if (dataHora.TimeOfDay < new TimeSpan(6, 0, 0))
                dataHora = DateTime.Today.AddHours(6);
            else if (dataHora.TimeOfDay > new TimeSpan(22, 0, 0))
                dataHora = DateTime.Today.AddDays(1).AddHours(6);

            // Act
            var acesso = Acesso.Criar(tipo, colaborador, dataHora);

            // Assert
            Assert.NotNull(acesso);
        }

        [Fact]
        public void CriarAcesso_Invalido_DeveLancarExcecao()
        {
            // validando a criação de acesso com tipo invalido, deve lançar exceção
            var aluno = AlunoValido();
            var tipo = (EPessoaTipo)5; // tipo invalido
            var dataHora = DateTime.Today.AddHours(8);

            var exception = Assert.Throws<DomainException>(() => Acesso.Criar(tipo, aluno, dataHora));
            Console.WriteLine(exception.Message);
            //Assert.Equal("TIPO_INVALIDO", exception.Message);
        }
        [Fact]
        public void CriarAcesso_Valido_VerificarNormalizado()
        {
            var logradouro = Logradouro.Criar("12345678", "Rua A", "Centro", "Cidade", "SP", "Brasil");
            var dataNascimento = DateOnly.FromDateTime(DateTime.Today.AddYears(-20));

            var foto = Arquivo.Criar(new byte[1], ".jpg");

            var tipo = EColaboradorTipo.Instrutor;
            var vinculo = EColaboradorVinculo.CLT;
            var dataAdmissao = new DateOnly(2025, 02, 02);

            var acessoAluno = Aluno.Criar("Gustavo Kley", "12345678901", dataNascimento, "11999999999", "gustavo@email.com", logradouro, "123", "Apto 1", "Senha@1", foto);
            var acessoColaborador = Colaborador.Criar("Gustavo Kley", "12345678901", dataNascimento, "11999999999", "gustavo@email.com", logradouro, "123", "Apto 1", "Senha@1",
            foto, dataAdmissao, tipo, vinculo);
            // validando normalização de acesso aluno
            Assert.Equal("Gustavo Kley", acessoAluno.Nome); 
            Assert.Equal("12345678901", acessoAluno.Cpf);
            Assert.Equal(dataNascimento, acessoAluno.DataNascimento);
            Assert.Equal("11999999999", acessoAluno.Telefone);
            Assert.Equal("gustavo@email.com", acessoAluno.Email);
            Assert.Equal(logradouro, acessoAluno.Endereco);
            Assert.Equal("123", acessoAluno.Numero);
            Assert.Equal("Apto 1", acessoAluno.Complemento);
            Assert.Equal("Senha@1", acessoAluno.Senha);
            Assert.Equal(foto, acessoAluno.Foto);

            // validando normalização de acesso colaborador
            Assert.Equal("Gustavo Kley", acessoColaborador.Nome); 
            Assert.Equal("12345678901", acessoColaborador.Cpf);
            Assert.Equal(dataNascimento, acessoColaborador.DataNascimento);
            Assert.Equal("11999999999", acessoAluno.Telefone);
            Assert.Equal("gustavo@email.com", acessoColaborador.Email);
            Assert.Equal(logradouro, acessoColaborador.Endereco);
            Assert.Equal("123", acessoColaborador.Numero);
            Assert.Equal("Apto 1", acessoColaborador.Complemento);
            Assert.Equal("Senha@1", acessoColaborador.Senha);
            Assert.Equal(dataAdmissao, acessoColaborador.DataAdmissao);
            Assert.Equal(tipo, acessoColaborador.Tipo);
            Assert.Equal(vinculo, acessoColaborador.Vinculo);

        }
        [Fact]
        public void CriarAcesso_Invalido_VerificarMessageExcecao()
        {
            var logradouro = Logradouro.Criar("12345678", "Rua A", "Centro", "Cidade", "SP", "Brasil");
            var dataNascimento = DateOnly.FromDateTime(DateTime.Today.AddYears(-20));
            var dataAdmissao = new DateOnly(2025, 01, 02);
            var foto = Arquivo.Criar(new byte[1], ".jpg");
            var tipo = EColaboradorTipo.Instrutor;
            var vinculo = EColaboradorVinculo.CLT;
            var acessoAluno = Aluno.Criar("Gustavo Kley", "12345678901", dataNascimento, "11999999999", "gustavo@email.com", logradouro, "123", "Apto 1", "Senha@1", foto);
            var acessoColaborador = Colaborador.Criar("Gustavo Kley", "12345678901", dataNascimento, "11999999999", "gustavo@email.com", logradouro, "123", "Apto 1", "Senha@1",
            foto, dataAdmissao, tipo, vinculo);

            var exception = Assert.Throws<DomainException>(() => Aluno.Criar("", "12345678901", dataNascimento, "11999999999", "gustavo@email.com", logradouro, "123", "Apto 1", "Senha@1", foto));
            Assert.Equal("NOME_OBRIGATORIO", exception.Message); // validando a mensagem de exceção
        }
    }
}
