﻿using AcademiaDoZe.Domain.Entities;
using AcademiaDoZe.Domain.Enums;
using AcademiaDoZe.Domain.Exceptions;
using AcademiaDoZe.Domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace AcademiaDoZe.Domain.Tests
{
    public class MatriculaDomainTests
    {
        [Fact]
        public void CriarMatricula_Valida_NaoDeveLancarExcecao()
        {
            var dataNascimento = new DateOnly(2005, 11, 19);
            var dataInicio = new DateOnly(2025, 08, 01);
            var dataFim = new DateOnly(2025, 08, 04);
            var logradouro = Logradouro.Criar("12345670", "Rua A", "Centro", "Cidade", "SP", "Brasil");
            var arquivo = Arquivo.Criar([1], ".jpg");
            var aluno = Aluno.Criar("Gustavo", "01234564562", dataNascimento, "01234564567", "gustavo@gmail.teste", logradouro, "numero", "complemento", "1234Abc", arquivo);
            var plano = ETipoPlano.Mensal;
            var restricao = EMatriculaRestricoes.PressaoAlta;
            var matricula = Matricula.Criar(aluno, plano, dataInicio, dataFim, "EMAGRECER", restricao, arquivo, "observacao ");
            //(Aluno alunoMatricula, ETipoPlano plano, DateOnly dataInicio, DateOnly dataFim, string objetivo, EMatriculaRestricoes restricoesMedicas, Arquivo laudoMedico, string observacoesRestricoes
            Assert.NotNull(matricula); // validando criação, não deve lançar exceção e não deve ser nulo
        }
        [Fact]

        public void CriarMatricula_Invalido_DeveLancarExcecao()
        {
            // validando a criação de matricula com arquivo inválido, deve lançar exceção
            var dataNascimento = new DateOnly(2005, 11, 19);
            var dataInicio = new DateOnly(2001, 01, 01);
            var dataFim = new DateOnly(2025, 08, 04);
            var logradouro = Logradouro.Criar("12345670", "Rua A", "Centro", "Cidade", "SP", "Brasil");
            var arquivo = Arquivo.Criar([1], ".jpg");
            var aluno = Aluno.Criar("Gustavo", "01234564562", dataNascimento, "01234564567", "gustavo@gmail.teste", logradouro, "numero", "complemento", "1234Abc", arquivo);
            var plano = ETipoPlano.Mensal;
            var restricao = EMatriculaRestricoes.PressaoAlta;
            var matricula = Matricula.Criar(aluno, plano, dataInicio, dataFim, "EMAGRECER", restricao, arquivo, "observacao ");
            Assert.Throws<DomainException>(() => Matricula.Criar(aluno, plano, dataInicio, dataFim, "", restricao, arquivo, "observacao "));
            Console.WriteLine(aluno.ToString());
        }

        [Fact]
        public void CriarMatricula_Valido_VerificarNormalizado()
        {
            var dataNascimento = new DateOnly(2005, 11, 19);
            var dataInicio = new DateOnly(2025, 08, 01);
            var dataFim = new DateOnly(2025, 08, 04);
            var logradouro = Logradouro.Criar("12345670", "Rua A", "Centro", "Cidade", "SP", "Brasil");
            var arquivo = Arquivo.Criar([1], ".jpg");
            var aluno = Aluno.Criar("Gustavo", "01234564562", dataNascimento, "01234564567", "gustavo@gmail.teste", logradouro, "numero", "complemento", "1234Abc", arquivo);
            var plano = ETipoPlano.Mensal;
            var restricao = EMatriculaRestricoes.PressaoAlta;
            var matricula = Matricula.Criar(aluno, plano, dataInicio, dataFim, "EMAGRECER", restricao, arquivo, "observacao");
            Assert.Equal(aluno, matricula.AlunoMatricula);
            Assert.Equal(plano, matricula.Plano); // validando normalização
            Assert.Equal(dataInicio, matricula.DataInicio);
            Assert.Equal(dataFim, matricula.DataFim);
            Assert.Equal("EMAGRECER", matricula.Objetivo);
            Assert.Equal(restricao, matricula.RestricoesMedicas);
            Assert.Equal(arquivo, matricula.LaudoMedico);
            Assert.Equal("observacao", matricula.ObservacoesRestricoes);

        }
        [Fact]
        public void CriarMatricula_Invalido_VerificarMessageExcecao()
        {
            var dataNascimento = new DateOnly(2005, 11, 19);
            var dataInicio = new DateOnly(2025, 08, 01);
            var dataFim = new DateOnly(2025, 08, 04);
            var logradouro = Logradouro.Criar("12345670", "Rua A", "Centro", "Cidade", "SP", "Brasil");
            var arquivo = Arquivo.Criar([1], ".jpg");
            var aluno = Aluno.Criar("Gustavo", "01234564562", dataNascimento, "01234564567", "gustavo@gmail.teste", logradouro, "numero", "complemento", "1234Abc", arquivo);
            var plano = ETipoPlano.Mensal ;
            var restricao = EMatriculaRestricoes.PressaoAlta;
            var exception = Assert.Throws<DomainException>(() => Matricula.Criar(aluno, plano, dataInicio, dataFim, "", restricao, arquivo, "observacao"));
            Assert.Equal("OBJETIVO_OBRIGATORIO", exception.Message); // validando a mensagem de exceção
        }
    }
}
