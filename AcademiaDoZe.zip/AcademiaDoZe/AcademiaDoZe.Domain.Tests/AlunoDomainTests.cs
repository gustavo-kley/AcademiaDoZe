﻿using AcademiaDoZe.Domain.Entities;
using AcademiaDoZe.Domain.Exceptions;
using AcademiaDoZe.Domain.ValueObjects;
//Gustavo vinicius ribeiro kley

namespace AcademiaDoZe.Domain.Tests
{
    public class AlunoDomainTests
    {
        [Fact]
        public void CriarAluno_Valido_NaoDeveLancarExcecao()
        {
            var dataNascimento = new DateOnly(2005, 11, 10);
            var logradouro = Logradouro.Criar("12345670", "Rua A", "Centro", "Cidade", "SP", "Brasil");
            var arquivo = Arquivo.Criar([1], ".jpg");
            var aluno = Aluno.Criar("Gustavo", "01234564562", dataNascimento, "01234564567", "gustavo@gmail.teste", logradouro, "numero", "complemento", "1234Abc", arquivo);
            //(string nome, string cpf, DateOnly dataNascimento, string telefone, string email, Logradouro endereco, string numero, string complemento, string senha, Arquivo foto
            Assert.NotNull(aluno); // validando criação, não deve lançar exceção e não deve ser nulo
        }
        [Fact]
        public void CriarAluno_Invalido_DeveLancarExcecao()
        {
            // validando a criação de aluno com CPF inválido, deve lançar exceção
            var dataNascimento = new DateOnly(2005, 11, 10);
            var logradouro = Logradouro.Criar("12345670", "Rua A", "Centro", "Cidade", "SP", "Brasil");
            var arquivo = Arquivo.Criar([1], ".jpg");
            Assert.Throws<DomainException>(() => Aluno.Criar("Gustavo", "012345645672", dataNascimento, "01234564567", "gustavo@gmail.teste", logradouro, "numero", "complemento", "1234Abc", arquivo));
        }

        [Fact]
        public void CriarAluno_Valido_VerificarNormalizado()
        {
            var dataNascimento = new DateOnly(2005, 11, 10);
            var logradouro = Logradouro.Criar("12345670", "Rua A", "Centro", "Cidade", "SP", "Brasil");
            var arquivo = Arquivo.Criar([1], ".jpg");
            var aluno = Aluno.Criar("Gustavo", "01234564562", dataNascimento, "01234564567", "gustavo@gmail.teste", logradouro, "numero", "complemento", "1234Abc", arquivo);
            Assert.Equal("Gustavo", aluno.Nome);
            Assert.Equal("01234564562", aluno.Cpf); // validando normalização
            Assert.Equal(dataNascimento, aluno.DataNascimento);
            Assert.Equal("01234564567", aluno.Telefone);
            Assert.Equal("gustavo@gmail.teste", aluno.Email);
            Assert.Equal(logradouro, aluno.Endereco);
            Assert.Equal("numero", aluno.Numero);
            Assert.Equal("complemento", aluno.Complemento);
            Assert.Equal("1234Abc", aluno.Senha);
            Assert.Equal(arquivo, aluno.Foto);

        }
        [Fact]
        public void CriarAluno_Invalido_VerificarMessageExcecao()
        {
            var dataNascimento = new DateOnly(2005, 11, 10);
            var logradouro = Logradouro.Criar("12345670", "Rua A", "Centro", "Cidade", "SP", "Brasil");
            var arquivo = Arquivo.Criar([1], ".jpg");
            var exception = Assert.Throws<DomainException>(() => Aluno.Criar("Gustavo", "012345645632", dataNascimento, "01234564567", "gustavo@gmail.teste", logradouro, "numero", "complemento", "1234Abc", arquivo));
            Assert.Equal("CPF_DIGITOS", exception.Message); // validando a mensagem de exceção
        }
    }
}
