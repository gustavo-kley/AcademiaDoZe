﻿using AcademiaDoZe.Domain.Entities;
using AcademiaDoZe.Domain.Enums;
using AcademiaDoZe.Domain.Exceptions;
using AcademiaDoZe.Domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademiaDoZe.Domain.Tests
{
    public class ColaboradorDomainTests
    {
        [Fact]
        public void CriarColaborador_Valido_NaoDeveLancarExcecao()
        {
            var dataNascimento = new DateOnly(2005, 11, 19);
            var logradouro = Logradouro.Criar("12345670", "Rua A", "Centro", "Cidade", "SP", "Brasil");
            var arquivo = Arquivo.Criar([1], ".jpg");
            var dataAdmissao = new DateOnly(2025, 08, 06);
            var tipo = EColaboradorTipo.Atendente;
            var vinculo = EColaboradorVinculo.CLT;
            var colaborador = Colaborador.Criar("Gustavo", "12345678901", dataNascimento, "49984093283", "gustavo@gmail.teste", logradouro, "123", "complemento", "1234Abcd", arquivo, dataAdmissao, tipo, vinculo);
            Assert.NotNull(colaborador); // validando criação, não deve lançar exceção e não deve ser nulo
        }
        [Fact]
        public void CriarColaborador_Invalido_DeveLancarExcecao()
        {
            // validando a criação de logradouro com CPF inválido, deve lançar exceção
            var dataNascimento = new DateOnly(2005, 11, 19);
            var logradouro = Logradouro.Criar("12345670", "Rua A", "Centro", "Cidade", "SP", "Brasil");
            var arquivo = Arquivo.Criar([1], ".jpg");
            var dataAdmissao = new DateOnly(2025, 08, 06);
            var tipo = EColaboradorTipo.Atendente;
            var vinculo = EColaboradorVinculo.CLT;
            Assert.Throws<DomainException>(() => Colaborador.Criar("Gustavo", "123456789012", dataNascimento, "49984093283", "gustavo@gmail.teste", logradouro, "123", "complemento", "1234Abcd",
            arquivo, dataAdmissao, tipo, vinculo));
        }
        [Fact]
        public void CriarColaborador_Valido_VerificarNormalizado()
        {
            var dataNascimento = new DateOnly(2005, 11, 19);
            var logradouro = Logradouro.Criar("12345670", "Rua A", "Centro", "Cidade", "SP", "Brasil");
            var arquivo = Arquivo.Criar([1], ".jpg");
            var dataAdmissao = new DateOnly(2025, 08, 06);
            var tipo = EColaboradorTipo.Atendente;
            var vinculo = EColaboradorVinculo.CLT;
            var colaborador = Colaborador.Criar("Gustavo", "12345678901", dataNascimento, "49984093283", "gustavo@gmail.teste", logradouro, "123", "complemento", "1234Abcd",
            arquivo, dataAdmissao, tipo, vinculo);
            Assert.Equal("Gustavo", colaborador.Nome); // validando normalização
            Assert.Equal("12345678901", colaborador.Cpf);
            Assert.Equal(dataNascimento, colaborador.DataNascimento);
            Assert.Equal("49984093283", colaborador.Telefone);
            Assert.Equal("gustavo@gmail.teste", colaborador.Email);
            Assert.Equal(logradouro, colaborador.Endereco);
            Assert.Equal("123", colaborador.Numero);
            Assert.Equal("complemento", colaborador.Complemento);
            Assert.Equal("1234Abcd", colaborador.Senha);

        }
        [Fact]
        public void CriarColaborador_Invalido_VerificarMessageExcecao()
        {
            var dataNascimento = new DateOnly(2005, 11, 19);
            var logradouro = Logradouro.Criar("12345670", "Rua A", "Centro", "Cidade", "SP", "Brasil");
            var arquivo = Arquivo.Criar([1], ".jpg");
            var dataAdmissao = new DateOnly(2025, 08, 06);
            var tipo = EColaboradorTipo.Atendente;
            var vinculo = EColaboradorVinculo.CLT;
            var exception = Assert.Throws<DomainException>(() => Colaborador.Criar("Gustavo", "233232232322", dataNascimento, "49984093283", "gustavo@gmail.teste", logradouro, "123", "complemento", "1234Abcd",
            arquivo, dataAdmissao, tipo, vinculo));
            var mensagens = new[] { "CPF_OBRIGATORIO", "CPF_DIGITOS" };
            Assert.Contains(exception.Message, mensagens);
        }
    }
}


