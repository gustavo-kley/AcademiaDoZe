﻿// Gustavo Vinicius Ribeiro Kley
using AcademiaDoZe.Domain.Entities;
using AcademiaDoZe.Domain.Enums;
using AcademiaDoZe.Domain.Repositories;
using AcademiaDoZe.Infrastructure.Repositories;

namespace AcademiaDoZe.Infrastructure.Tests
{
    public class AcessoInfrastructureTests : TestBase
    {
        [Fact]
        public async Task Acesso_Adicionar_Obter()
        {
            // Criar aluno de teste
            var repoAluno = new AlunoRepository(ConnectionString, DatabaseType);
            var aluno = await repoAluno.ObterPorId(1); // Assumindo que existe
            Assert.NotNull(aluno);

            var acesso = Acesso.Criar(EPessoaTipo.Aluno, aluno!, DateTime.Now.AddMinutes(1));

            var repoAcesso = new AcessoRepository(ConnectionString, DatabaseType);
            var acessoInserido = await repoAcesso.Adicionar(acesso);

            Assert.NotNull(acessoInserido);
            Assert.True(acessoInserido.Id > 0);

            // Obter pelo Id
            var acessoObtido = await repoAcesso.ObterPorId(acessoInserido.Id);
            Assert.NotNull(acessoObtido);
            Assert.Equal(acessoInserido.Id, acessoObtido.Id);
        }

        [Fact]
        public async Task Acesso_Atualizar()
        {
            var repoAcesso = new AcessoRepository(ConnectionString, DatabaseType);
            var acessoExistente = (await repoAcesso.ObterTodos()).FirstOrDefault();
            Assert.NotNull(acessoExistente);

            // Atualizar dataHora
            var novaDataHora = acessoExistente.DataHora.AddMinutes(5);
            var acessoAtualizado = Acesso.Criar(acessoExistente.Tipo, acessoExistente.AlunoColaborador, novaDataHora);

            // Manter Id
            typeof(Entity).GetProperty("Id")?.SetValue(acessoAtualizado, acessoExistente.Id);

            var resultado = await repoAcesso.Atualizar(acessoAtualizado);
            Assert.Equal(novaDataHora, resultado.DataHora);
        }

        [Fact]
        public async Task Acesso_ObterTodos()
        {
            var repoAcesso = new AcessoRepository(ConnectionString, DatabaseType);
            var acessos = await repoAcesso.ObterTodos();
            Assert.NotNull(acessos);
            Assert.True(acessos.Any());
        }
    }
}