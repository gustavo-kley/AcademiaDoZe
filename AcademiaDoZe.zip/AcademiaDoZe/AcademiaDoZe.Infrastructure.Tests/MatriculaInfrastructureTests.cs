﻿using AcademiaDoZe.Domain.Entities;
using AcademiaDoZe.Domain.Enums;
using AcademiaDoZe.Domain.Repositories;
using AcademiaDoZe.Domain.ValueObjects;
using AcademiaDoZe.Infrastructure.Repositories;

namespace AcademiaDoZe.Infrastructure.Tests
{
    public class MatriculaInfrastructureTests : TestBase
    {
        [Fact]
        public async Task Matricula_Adicionar_ObterPorId()
        {
            // Obter um aluno existente
            var repoAluno = new AlunoRepository(ConnectionString, DatabaseType);
            var aluno = await repoAluno.ObterPorCpf("12345678900");
            Assert.NotNull(aluno);

            // Criar um arquivo de exemplo
            Arquivo laudo = Arquivo.Criar(new byte[] { 1, 2, 3 });

            // Criar matrícula
            var matricula = Matricula.Criar(
                aluno!,
                ETipoPlano.Mensal,
                DateOnly.FromDateTime(DateTime.Today),
                DateOnly.FromDateTime(DateTime.Today.AddMonths(1)),
                "Condicionamento físico",
                EMatriculaRestricoes.None,
                laudo
            );

            // Adicionar
            var repoMatricula = new MatriculaRepository(ConnectionString, DatabaseType);
            var matriculaInserida = await repoMatricula.Adicionar(matricula);

            Assert.NotNull(matriculaInserida);
            Assert.True(matriculaInserida.Id > 0);

            // Obter por ID
            var matriculaObtida = await repoMatricula.ObterPorId(matriculaInserida.Id);
            Assert.NotNull(matriculaObtida);
            Assert.Equal("Condicionamento físico", matriculaObtida.Objetivo);
        }

        [Fact]
        public async Task Matricula_Atualizar()
        {
            var repoMatricula = new MatriculaRepository(ConnectionString, DatabaseType);

            // Obter matrícula existente
            var todasMatriculas = await repoMatricula.ObterTodos();
            var matriculaExistente = todasMatriculas.FirstOrDefault();
            Assert.NotNull(matriculaExistente);

            // Atualizar dados
            var laudo = Arquivo.Criar(new byte[] { 4, 5, 6 });
            var matriculaAtualizada = Matricula.Criar(
                matriculaExistente.AlunoMatricula,
                ETipoPlano.Semestral,
                matriculaExistente.DataInicio,
                matriculaExistente.DataFim,
                "Treinamento avançado",
                matriculaExistente.RestricoesMedicas,
                laudo,
                "Atualizado para teste"
            );

            // Definir ID usando reflection
            typeof(Entity).GetProperty("Id")?.SetValue(matriculaAtualizada, matriculaExistente.Id);

            var resultadoAtualizacao = await repoMatricula.Atualizar(matriculaAtualizada);
            Assert.NotNull(resultadoAtualizacao);
            Assert.Equal("Treinamento avançado", resultadoAtualizacao.Objetivo);
        }

        [Fact]
        public async Task Matricula_Remover_ObterPorId()
        {
            var repoMatricula = new MatriculaRepository(ConnectionString, DatabaseType);

            var todasMatriculas = await repoMatricula.ObterTodos();
            var matriculaExistente = todasMatriculas.FirstOrDefault();
            Assert.NotNull(matriculaExistente);

            var resultadoRemover = await repoMatricula.Remover(matriculaExistente.Id);
            Assert.True(resultadoRemover);

            var resultadoObtido = await repoMatricula.ObterPorId(matriculaExistente.Id);
            Assert.Null(resultadoObtido);
        }

        [Fact]
        public async Task Matricula_ObterPorAluno()
        {
            var repoAluno = new AlunoRepository(ConnectionString, DatabaseType);
            var aluno = await repoAluno.ObterPorCpf("12345678900");
            Assert.NotNull(aluno);

            var repoMatricula = new MatriculaRepository(ConnectionString, DatabaseType);
            var matriculas = await repoMatricula.ObterPorAluno(aluno!.Id);
            Assert.NotNull(matriculas);
        }

        [Fact]
        public async Task Matricula_ObterAtivas()
        {
            var repoMatricula = new MatriculaRepository(ConnectionString, DatabaseType);
            var matriculasAtivas = await repoMatricula.ObterAtivas();
            Assert.NotNull(matriculasAtivas);
        }

        [Fact]
        public async Task Matricula_ObterVencendoEmDias()
        {
            var repoMatricula = new MatriculaRepository(ConnectionString, DatabaseType);
            var matriculasVencendo = await repoMatricula.ObterVencendoEmDias(7);
            Assert.NotNull(matriculasVencendo);
        }
    }
}
