﻿using AcademiaDoZe.Application.DTOs;
using AcademiaDoZe.Application.Interfaces;
using AcademiaDoZe.Application.Mappings;
using AcademiaDoZe.Domain.Repositories;
using AcademiaDoZe.Application.Security;
namespace AcademiaDoZe.Application.Services
{
    public class AlunoService : IAlunoService
    {
        private readonly Func<IAlunoRepository> _repoFactory;
        public AlunoService(Func<IAlunoRepository> repoFactory)
        {
            _repoFactory = repoFactory ?? throw new ArgumentNullException(nameof(repoFactory));
        }
        public async Task<AlunoDTO> AdicionarAsync(AlunoDTO AlunoDto)
        {
            // Verifica se já existe um Aluno com o mesmo CPF
            if (await _repoFactory().CpfJaExiste(AlunoDto.Cpf))

            {
                throw new InvalidOperationException($"Já existe um Aluno cadastrado com o CPF {AlunoDto.Cpf}.");
            }
            // Hash da senha

            if (!string.IsNullOrWhiteSpace(AlunoDto.Senha))

            {
                AlunoDto.Senha = PasswordHasher.Hash(AlunoDto.Senha);
            }
            // Cria a entidade de domínio a partir do DTO
            var Aluno = AlunoDto.ToEntity();
            // Salva no repositório
            await _repoFactory().Adicionar(Aluno);
            // Retorna o DTO atualizado com o ID gerado
            return Aluno.ToDto();

        }
        public async Task<AlunoDTO> AtualizarAsync(AlunoDTO AlunoDto)
        {
            // Verifica se o Aluno existe

            var AlunoExistente = await _repoFactory().ObterPorId(AlunoDto.Id) ?? throw new KeyNotFoundException($"Aluno ID {AlunoDto.Id} não encontrado.");

            // Verifica se o novo CPF já está em uso por outro Aluno

            if (await _repoFactory().CpfJaExiste(AlunoDto.Cpf, AlunoDto.Id))

            {
                throw new InvalidOperationException($"Já existe outro Aluno cadastrado com o CPF {AlunoDto.Cpf}.");
            }
            // Se nova senha informada, aplicar hash

            if (!string.IsNullOrWhiteSpace(AlunoDto.Senha))

            {
                AlunoDto.Senha = PasswordHasher.Hash(AlunoDto.Senha);
            }
            // a partir dos dados do dto e do existente, cria uma nova instância com os valores atualizados

            var AlunoAtualizado = AlunoExistente.UpdateFromDto(AlunoDto);
            // Atualiza no repositório
            await _repoFactory().Atualizar(AlunoAtualizado);
            return AlunoAtualizado.ToDto();

        }

        public async Task<AlunoDTO> ObterPorIdAsync(int id)
        {
            var Aluno = await _repoFactory().ObterPorId(id);
            return (Aluno != null) ? Aluno.ToDto() : null!;

        }
        public async Task<IEnumerable<AlunoDTO>> ObterTodosAsync()
        {
            var Alunoes = await _repoFactory().ObterTodos();
            return [.. Alunoes.Select(c => c.ToDto())];

        }
        public async Task<bool> RemoverAsync(int id)
        {
            var Aluno = await _repoFactory().ObterPorId(id);

            if (Aluno == null)

            {
                return false;
            }
            await _repoFactory().Remover(id);

            return true;

        }
        public async Task<AlunoDTO> ObterPorCpfAsync(string cpf)
        {
            if (string.IsNullOrWhiteSpace(cpf))
                throw new ArgumentException("CPF não pode ser vazio.", nameof(cpf));
            cpf = new string([.. cpf.Where(char.IsDigit)]);
            var Aluno = await _repoFactory().ObterPorCpf(cpf);
            return (Aluno != null) ? Aluno.ToDto() : null!;

        }
        public async Task<bool> CpfJaExisteAsync(string cpf, int? id = null)
        {
            return await _repoFactory().CpfJaExiste(cpf, id);
        }
        public async Task<bool> TrocarSenhaAsync(int id, string novaSenha)
        {
            if (string.IsNullOrWhiteSpace(novaSenha))
                throw new ArgumentException("Nova senha inválida.", nameof(novaSenha));
            var hash = PasswordHasher.Hash(novaSenha);
            return await _repoFactory().TrocarSenha(id, hash);

        }
    }
}