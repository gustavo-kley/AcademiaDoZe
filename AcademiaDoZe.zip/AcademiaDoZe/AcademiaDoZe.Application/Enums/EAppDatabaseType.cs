﻿namespace AcademiaDoZe.Application.Enums
{
    public enum EAppDatabaseType
    {
        SqlServer,
        MySql
    }
}